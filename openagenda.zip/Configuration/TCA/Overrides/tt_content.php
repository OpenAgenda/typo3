<?php

declare(strict_types=1);

use TYPO3\CMS\Extbase\Utility\ExtensionUtility;

defined('TYPO3') or die();

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Agenda',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_agenda'
);

$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_excludelist']['openagenda_agenda']='pages,layout,select_key,recursive';
$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist']['openagenda_agenda']='pi_flexform';

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue(
    'openagenda_agenda',
    'FILE:EXT:openagenda/Configuration/Flexforms/PluginAgenda.xml'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Preview',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_preview'
);

$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_excludelist']['openagenda_preview']='pages,layout,select_key,recursive';
$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist']['openagenda_preview']='pi_flexform';

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue(
    'openagenda_preview',
    'FILE:EXT:openagenda/Configuration/Flexforms/PluginPreview.xml'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Active',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_active_filter'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Additional',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_additional_filter'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Cities',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_cities_filter'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Daterange',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_daterange_filter'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Favorites',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_favorites_filter'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Keywords',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_keywords_filter'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Map',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_map_filter'
);

$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_excludelist']['openagenda_map']='pages,layout,select_key,recursive';
$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist']['openagenda_map']='pi_flexform';

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue(
    'openagenda_map',
    'FILE:EXT:openagenda/Configuration/Flexforms/PluginMap.xml'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Relative',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_relative_filter'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Search',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_search_filter'
);

$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_excludelist']['openagenda_search']='pages,layout,select_key,recursive';
$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist']['openagenda_search']='pi_flexform';

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue(
    'openagenda_search',
    'FILE:EXT:openagenda/Configuration/Flexforms/PluginSearch.xml'
);

ExtensionUtility::registerPlugin(
    'Openagenda',
    'Total',
    'LLL:EXT:openagenda/Resources/Private/Language/locallang_tca.xlf:tt_content.list_type.openagenda_total_filter'
);