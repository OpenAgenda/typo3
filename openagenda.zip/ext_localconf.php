<?php
defined('TYPO3') or die();

use TYPO3\CMS\Extbase\Utility\ExtensionUtility;
use Openagenda\Openagenda\Controller\OpenagendaController;

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Agenda',
    [OpenagendaController::class => 'agenda, event, filtersCallback, ajaxCallback'],
    [OpenagendaController::class => 'agenda, event, filtersCallback, ajaxCallback']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Preview',
    [OpenagendaController::class => 'preview'],
    [OpenagendaController::class => 'preview']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Ajax',
    [OpenagendaController::class => 'ajaxCallback'],
    [OpenagendaController::class => 'ajaxCallback']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Filters',
    [OpenagendaController::class => 'filtersCallback'],
    [OpenagendaController::class => 'filtersCallback']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Active',
    [OpenagendaController::class => 'activeFilter'],
    [OpenagendaController::class => 'activeFilter']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Additional',
    [OpenagendaController::class => 'additionalFilter'],
    [OpenagendaController::class => 'additionalFilter']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Cities',
    [OpenagendaController::class => 'citiesFilter'],
    [OpenagendaController::class => 'citiesFilter']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Daterange',
    [OpenagendaController::class => 'daterangeFilter'],
    [OpenagendaController::class => 'daterangeFilter']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Favorites',
    [OpenagendaController::class => 'favoritesFilter'],
    [OpenagendaController::class => 'favoritesFilter']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Keywords',
    [OpenagendaController::class => 'keywordsFilter'],
    [OpenagendaController::class => 'keywordsFilter']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Map',
    [OpenagendaController::class => 'mapFilter'],
    [OpenagendaController::class => 'mapFilter']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Relative',
    [OpenagendaController::class => 'relativeFilter'],
    [OpenagendaController::class => 'relativeFilter']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Search',
    [OpenagendaController::class => 'searchFilter'],
    [OpenagendaController::class => 'searchFilter']
);

ExtensionUtility::configurePlugin(
    'Openagenda',
    'Total',
    [OpenagendaController::class => 'totalFilter'],
    [OpenagendaController::class => 'totalFilter']
);

call_user_func(function()
{
    $extensionKey = 'openagenda';

    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTypoScript(
        $extensionKey,
        'setup',
        "@import 'EXT:openagenda/Configuration/TypoScript/setup.typoscript'"
    );
});